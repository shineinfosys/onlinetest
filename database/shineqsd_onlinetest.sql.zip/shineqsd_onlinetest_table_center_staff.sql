
-- --------------------------------------------------------

--
-- Table structure for table `center_staff`
--

DROP TABLE IF EXISTS `center_staff`;
CREATE TABLE IF NOT EXISTS `center_staff` (
  `service_center_code` varchar(15) NOT NULL,
  `location` varchar(150) DEFAULT NULL,
  `region` text NOT NULL,
  `region_id` int(2) NOT NULL,
  PRIMARY KEY (`service_center_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `center_staff`
--

INSERT INTO `center_staff` (`service_center_code`, `location`, `region`, `region_id`) VALUES
('INGJ01043', 'Sumul Dairy', 'Surat', 7),
('INGJ01037', 'Pandesara', 'Surat', 7),
('INGJ01001', 'Adajan', 'Surat', 7),
('INGJ01027', 'Magdalla Surat', 'Surat', 7),
('INGJ01049', 'Vapi', 'South', 6),
('INGJ01048', 'Valsad', 'South', 6),
('INGJ01042', 'Silvassa', 'South', 6),
('INGJ01034', 'Navsari', 'South', 6),
('INGJ01008', 'Bardoli', 'South', 6),
('INGJ01026', 'Kamrej', 'South', 6),
('INGJ01046', 'Una', 'Saurastra2', 5),
('INGJ01050', 'Veraval', 'Saurastra2', 5),
('INGJ01039', 'Porbandar', 'Saurastra2', 5),
('INGJ01011', 'Bhavnagar', 'Saurastra2', 5),
('INGJ01012', 'Bhuj', 'Saurastra2', 5),
('INGJ01013', 'Botad', 'Saurastra2', 5),
('INGJ01018', 'Gandhidham', 'Saurastra2', 5),
('INGJ01032', 'Morbi', 'Saurastra1', 4),
('INGJ01040', 'Rajkot', 'Saurastra1', 4),
('INGJ01004', 'Amreli', 'Saurastra1', 4),
('INGJ01016', 'Devbhumi Dwarka', 'Saurastra1', 4),
('INGJ01017', 'Dhebar Road', 'Saurastra1', 4),
('INGJ01021', 'Gondal', 'Saurastra1', 4),
('INGJ01023', 'Jamnagar', 'Saurastra1', 4),
('INGJ01024', 'Junagadh', 'Saurastra1', 4),
('INGJ01015', 'Deesa', 'North', 3),
('INGJ01038', 'Patan', 'North', 3),
('INGJ01045', 'Surendranagar', 'North', 3),
('INGJ01036', 'Palanpur', 'North', 3),
('INGJ01031', 'Modasa', 'North', 3),
('INGJ01028', 'Mahesana', 'North', 3),
('INGJ01019', 'Gandhinagar', 'North', 3),
('INGJ01022', 'Himmatnagar', 'North', 3),
('INGJ01025', 'Kalol', 'North', 3),
('INGJ01047', 'Vadodara', 'Center', 2),
('INGJ01033', 'Nadiad', 'Center', 2),
('INGJ01030', 'Manjalpur', 'Center', 2),
('INGJ01003', 'Akota', 'Center', 2),
('INGJ01005', 'Anand', 'Center', 2),
('INGJ01006', 'Ankleshwar', 'Center', 2),
('INGJ01014', 'Dahod', 'Center', 2),
('INGJ01010', 'Bharuch', 'Center', 2),
('INGJ01020', 'Godhra', 'Center', 2),
('INGJ01041', 'Rto Circle', 'Ahmedabad', 1),
('INGJ01002', 'Ahmedabad', 'Ahmedabad', 1),
('INGJ01035', 'Odhav', 'Ahmedabad', 1),
('INGJ01029', 'Maninagar', 'Ahmedabad', 1),
('INGJ01', 'Warehouse', 'Warehouse', 1),
('INGJ01007', 'Bapunagar', 'Ahmedabad', 1),
('INGJ01009', 'Bavla', 'Ahmedabad', 1),
('INGJ01044', 'Surat', 'Surat', 7);
