
-- --------------------------------------------------------

--
-- Table structure for table `mst_admin`
--

DROP TABLE IF EXISTS `mst_admin`;
CREATE TABLE IF NOT EXISTS `mst_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loginid` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `user_type` int(11) NOT NULL,
  `region` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_admin`
--

INSERT INTO `mst_admin` (`id`, `loginid`, `pass`, `user_type`, `region`) VALUES
(1, 'admin', 'vivo@3251', 1, 'Ahmedabad'),
(2, 'swamivardhan', 'swami123', 0, 'South'),
(3, 'naresh_patel', 'vivo@123', 1, 'Ahmedabad'),
(4, 'jitendave', 'vivo@3251', 0, 'Saurastra2'),
(5, 'asifshekh', 'vivo@3251', 0, 'Saurastra1'),
(6, 'sagarthakkar', 'vivo@3251', 0, 'Surat'),
(7, 'rakeshchouhan', 'vivo@3251', 0, 'Center'),
(8, 'ankitpatel', 'vivo@3251', 0, 'North'),
(9, 'himanshu', 'vivo@3251', 0, 'Ahmedabad');
