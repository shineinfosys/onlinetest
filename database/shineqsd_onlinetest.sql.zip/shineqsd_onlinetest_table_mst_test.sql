
-- --------------------------------------------------------

--
-- Table structure for table `mst_test`
--

DROP TABLE IF EXISTS `mst_test`;
CREATE TABLE IF NOT EXISTS `mst_test` (
  `test_id` int(5) NOT NULL AUTO_INCREMENT,
  `sub_id` int(5) DEFAULT NULL,
  `test_name` varchar(50) DEFAULT NULL,
  `total_que` varchar(15) DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '10',
  `exam_release` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_test`
--

INSERT INTO `mst_test` (`test_id`, `sub_id`, `test_name`, `total_que`, `time`, `exam_release`, `type`) VALUES
(18, 12, 'Basic Knowledge', '6', 10, 1, 0),
(19, 12, 'Full Form', '20', 10, 1, 0),
(20, 13, 'Long Term Evolution (LTE)', '10', 10, 1, 0),
(21, 13, 'Fundamentals of mobile communi', '5', 10, 1, 0),
(22, 13, 'Evolution of Mobile Radio Comm', '5', 10, 1, 0),
(23, 13, 'Networking', '10', 10, 1, 0),
(26, 15, 'Standardization', '12', 15, 1, 0),
(27, 15, '6s Standard [30March20]', '10', 10, 1, 0),
(28, 15, 'Repair & Inspection Modification', '10', 10, 1, 0),
(29, 15, 'Repair & Inspection Modification 2', '10', 10, 1, 0),
(30, 15, 'Company Culture', '6', 10, 1, 0),
(31, 15, 'Mobile Test JD', '5', 10, 1, 0),
(32, 12, 'Heating Standard & Multi-meter', '10', 10, 1, 0),
(33, 15, 'Log Process 1', '10', 10, 1, 0),
(34, 15, 'Log Process 2', '10', 10, 1, 0),
(35, 15, 'Repeat-Repair', '10', 10, 1, 0),
(36, 15, 'Inventory_MSL', '5', 5, 1, 0),
(37, 15, 'Handset_Return Process', '10', 10, 1, 0),
(38, 15, 'Happy Calling Process', '5', 5, 0, 1),
(39, 15, 'V19 Model Specification', '30', 20, 1, 0);
